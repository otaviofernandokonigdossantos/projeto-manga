<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1e1e1e;
            color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('background-skate.jpg');
            background-size: cover;
            background-position: center;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            max-width: 400px;
            width: 100%;
        }

        .container h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            color: #f5f5f5;
        }

        .input-field {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            display: inline-block;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
            background-color: #333;
            color: #f5f5f5;
            font-size: 16px;
        }

        .input-field:focus {
            outline: none;
            border: 2px solid #a71313;
        }

        .submit-btn {
            width: 100%;
            background-color: #a71313;
            color: white;
            padding: 14px 20px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        .submit-btn:hover {
            background-color: #a71313;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            color: #f5f5f5;
        }

        .footer a {
            color: #a71313;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Login - RestStore</h1>

    <form action="/submit_login" method="post">
        <input type="email" name="email" class="input-field" placeholder="E-mail" required>
        <input type="password" name="senha" class="input-field" placeholder="Senha" required>
        <button type="submit" class="submit-btn">Entrar</button>
    </form>

    <div class="footer">
        <p>Não tem uma conta? <a href="cadastro.php">Cadastre-se</a></p>
    </div>
</div>

</body>
</html>
